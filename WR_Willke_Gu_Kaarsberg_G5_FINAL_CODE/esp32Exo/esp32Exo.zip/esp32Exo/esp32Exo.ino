/*
 * Brief description
 * 
 */

#include <ESP32Servo.h>
#include <string.h>

#define SERVO_PIN  12
#define SERVO_PIN2 13
#include <stdlib.h>

Servo elbow;
Servo wrist;

const int analogInPin1 = 25; // analog pin A1, GPIO 25
const int analogInPin2 = 34; // analog pin A2, GPIO 34
const int analogInPin3 = 39; // analog pin A3, GPIO 39
const int analogInPin4 = 36; // analog pin A4, GPIO 36

int sensorValue1 = 0; // values we want to plot
int sensorValue2 = 0;
int sensorValue3 = 0; 
int sensorValue4 = 0;

double posServo1 = 3040; //0 degrees 
double posServo2 = 0; //180 degrees 

double alpha_offset1 = 0.0;
double alpha_offset2 = 0.0;

bool motorAttach1 = false;
bool motorAttach2 = false;

double angle1 = 0.0;
double angle2 = 0.0;

void setup()
{
  Serial.begin(9600);//(115200);//(9600);
  Serial.setTimeout(10);
  pinMode(SERVO_PIN, OUTPUT);
  pinMode(SERVO_PIN2, OUTPUT);
  
  elbow.attach(SERVO_PIN); // PWM pin
  wrist.attach(SERVO_PIN2); // PWM pin
  delay(1000);
  
}

bool servoAttached = false;

void motor_working(double mode) //function used to attach / detach the servo according to input from python
{
  if (mode > 0.0 && servoAttached == false){
    elbow.attach(SERVO_PIN); // PWM pin
    wrist.attach(SERVO_PIN2); // PWM pin
    servoAttached = true;
  }
  else if (mode <= 0.0 && servoAttached == true){
    elbow.attach(SERVO_PIN); // PWM pin
    wrist.attach(SERVO_PIN2); // PWM pin
    servoAttached = false;
  }
}

double mapf(double x, double in_min, double in_max, double out_min, double out_max)
{
    return (x - in_min) * (out_max - out_min) / (in_max - in_min) + out_min;
}

//function, that inhibits the motor from turning more than the valid ROM, returns the limiting values in case it would surpass either
double safety(double x, double offset, double out_max, double out_min)
{
  if ((x+offset) < out_min){
    return out_min;
  }
  else if ((x+offset) > out_max){
    return out_max;
  }
  else{
    return x;
  }
}

void loop()
{
  sensorValue1 = analogRead(analogInPin1); // read the analog input
  sensorValue2 = analogRead(analogInPin2);
  sensorValue3 = analogRead(analogInPin3); // read the analog input
  sensorValue4 = analogRead(analogInPin4);

  //Serial.print(sensorValue1 - sensorValue2);
  //Serial.print(",");
  //Serial.print(sensorValue2);
  //Serial.print(",");
  //Serial.println(sensorValue3 - sensorValue4);
  //Serial.print(",");
  //Serial.println(sensorValue4); 

  String x = Serial.readStringUntil('\n');
  char* token;
  char* string;
  string = strdup(x.c_str()); //reading string from serial port 
  double data[2];
 
  // Split the string at the comma and convert to double
  int commaIndex = x.indexOf(',');
  if (commaIndex != -1) {
    data[0] = x.substring(0, commaIndex).toDouble();
    data[1] = x.substring(commaIndex + 1).toDouble();
  }
  //int i = 0;
  //while ((token = strsep(&string, ",")) != NULL) //retrieving both input values from the read string
  //{
  //  data[i] = atof(token);
  //  i += 1;
  //}


  //double q1 = data[0];
  //double q2 = data[1];


  //Serial.print(data[0]);
  //Serial.print(",");
  //Serial.print(data[1]);
  //Serial.print(",");
  Serial.print("<");
  Serial.print(sensorValue1);
  Serial.print(",");
  Serial.print(sensorValue2);
  Serial.print(",");
  Serial.print(sensorValue3);
  Serial.print(",");
  Serial.print(sensorValue4);
  Serial.println(">");

  //motor_working(validInput); 

  //angle1 = mapf(data[0], 0.0,3.14159, posServo1, posServo2); //linear mapping function for the desired angle
  //angle2 = mapf(data[1], 0.0,3.14159, posServo1, posServo2);
  
  //alpha_offset = 0.0;//mapf(alpha_offset, 0.0,3.14159/2.0, posServo1, posServo2);
  angle1 = safety(mapf(data[0], 0.0,3.14159, posServo1, posServo2), 0.0, posServo1, posServo2); //0.0 will be replaced by alpha_offset onve the IMU is connected to the system
  angle2 = safety(mapf(data[1], 0.0,3.14159, posServo1, posServo2), 0.0, posServo1, posServo2);
  //Serial.print(angle1);
  
  elbow.writeMicroseconds(angle1); //send the desired angle as input to the servomotor
  wrist.writeMicroseconds(angle2);

  delay(50);
}
